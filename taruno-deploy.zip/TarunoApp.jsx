import React from "react";
import { Star, ShoppingCart, Heart } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Classic Black Tee",
    price: "₹799",
    image: "https://i.imgur.com/5Z6h0B2.jpg",
    rating: 4.8,
  },
  {
    id: 2,
    name: "Minimalist White Tee",
    price: "₹749",
    image: "https://i.imgur.com/LrGdXlh.jpg",
    rating: 4.6,
  },
  {
    id: 3,
    name: "Retro Streetwear Tee",
    price: "₹899",
    image: "https://i.imgur.com/88U1y3a.jpg",
    rating: 4.9,
  },
  {
    id: 4,
    name: "Urban Grey Tee",
    price: "₹849",
    image: "https://i.imgur.com/Bm9Z7cb.jpg",
    rating: 4.7,
  },
  {
    id: 5,
    name: "Maroon Street Tee",
    price: "₹799",
    image: "https://i.imgur.com/7mjCmCh.jpg",
    rating: 4.5,
  },
  {
    id: 6,
    name: "Sky Blue Comfort Tee",
    price: "₹759",
    image: "https://i.imgur.com/kMEyOK2.jpg",
    rating: 4.6,
  }
];

export default function TarunoApp() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black to-gray-900 text-white p-6">
      <div className="flex flex-col items-center mb-12">
        <img
          src="https://cdn-icons-png.flaticon.com/512/892/892692.png"
          alt="TARUNO Logo"
          className="w-24 h-24 mb-4 drop-shadow-xl"
        />
        <h1 className="text-5xl font-bold text-center tracking-wider text-white drop-shadow-lg">TARUNO</h1>
        <p className="text-center text-gray-300 mt-2 text-lg italic">Premium. Bold. Iconic.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {products.map((product) => (
          <div key={product.id} className="bg-white text-black shadow-xl rounded-2xl">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-64 object-cover rounded-t-2xl"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-1">{product.name}</h2>
              <p className="text-gray-700 mb-2">{product.price}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-yellow-500">
                  <Star className="w-4 h-4" />
                  <span>{product.rating}</span>
                </div>
                <div className="flex gap-2">
                  <button className="border rounded-full p-2 hover:bg-gray-200">
                    <Heart className="w-4 h-4" />
                  </button>
                  <button className="bg-black text-white rounded-full p-2 hover:bg-gray-800">
                    <ShoppingCart className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
