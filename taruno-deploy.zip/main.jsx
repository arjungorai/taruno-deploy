import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import TarunoApp from './TarunoApp';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <TarunoApp />
  </React.StrictMode>
);